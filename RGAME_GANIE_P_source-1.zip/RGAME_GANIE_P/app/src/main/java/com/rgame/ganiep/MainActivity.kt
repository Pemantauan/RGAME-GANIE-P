package com.rgame.ganiep

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.content.pm.PackageManager

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 10, 14)
    private val panel = Color.rgb(24, 22, 29)
    private val red = Color.rgb(255, 45, 75)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var currentPage = "Home"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        showShell()
        showHome()
    }

    private fun rounded(color: Int, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun label(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun pad(v: View, all: Int = 16) {
        v.setPadding(all, all, all, all)
    }

    private fun card(title: String, subtitle: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel)
            pad(this, 16)
            addView(label(title, 16f, Color.WHITE, true))
            val sub = label(subtitle, 12f, Color.LTGRAY)
            sub.setPadding(0, 7, 0, 0)
            addView(sub)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = 12
            layoutParams = lp
        }
    }

    private fun showShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            pad(this, 18)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        brand.addView(label("R  RGAME GANIE P", 20f, Color.WHITE, true))
        brand.addView(label("GAMING CONTROL CENTER", 9f, red, true))
        header.addView(brand)
        val status = label("● READY", 10f, Color.GREEN, true)
        header.addView(status)
        root.addView(header)
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 18, 0, 16)
        }
        listOf("Home", "Games", "Tools", "Settings").forEach { name ->
            val b = Button(this).apply {
                text = name; textSize = 10f; isAllCaps = false
                setTextColor(if (currentPage == name) Color.WHITE else Color.LTGRAY)
                background = rounded(if (currentPage == name) red else panel, 14f)
                setOnClickListener { currentPage = name; showShell(); when(name) {
                    "Home" -> showHome()
                    "Games" -> showGames()
                    "Tools" -> showTools()
                    else -> showSettings()
                } }
            }
            val lp = LinearLayout.LayoutParams(0, 44, 1f); lp.marginEnd = 5
            nav.addView(b, lp)
        }
        root.addView(nav)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun title(t: String, sub: String) {
        content.addView(label(t, 25f, Color.WHITE, true))
        val s = label(sub, 12f, Color.LTGRAY)
        s.setPadding(0, 5, 0, 18)
        content.addView(s)
    }

    private fun showHome() {
        content.removeAllViews()
        title("Welcome back.", "Your gaming space. Tuned by you.")
        val hero = card("RGAME  /  CONTROL HUB", "Versi awal • Local mode • Android")
        hero.addView(label("PLAY SMARTER", 25f, red, true).apply { setPadding(0, 16, 0, 4) })
        hero.addView(label("Kelola game dan akses fitur gaming dari satu tempat.", 12f, Color.LTGRAY))
        content.addView(hero)
        content.addView(card("GAME LIBRARY", "Deteksi aplikasi yang memiliki ikon launcher."))
        content.addView(card("QUICK ACCESS", "Pilih game untuk membuka aplikasi dengan cepat."))
        content.addView(card("LOCAL SETTINGS", "Preferensi disimpan di perangkat ini."))
        val note = label("Catatan: metrik performa dan floating overlay belum aktif di versi awal ini.", 11f, Color.GRAY)
        note.setPadding(4, 8, 4, 12)
        content.addView(note)
    }

    @Suppress("DEPRECATION")
    private fun installedApps(): List<android.content.pm.ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        return if (Build.VERSION.SDK_INT >= 33)
            packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        else packageManager.queryIntentActivities(intent, 0)
    }

    private fun showGames() {
        content.removeAllViews()
        title("Game library", "Aplikasi yang tersedia di perangkat lu.")
        val apps = installedApps().filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        content.addView(label("${apps.size} aplikasi terdeteksi", 13f, red, true).apply { setPadding(0,0,0,12) })
        if (apps.isEmpty()) content.addView(card("Belum ada aplikasi", "Aplikasi launcher akan muncul di sini."))
        apps.forEach { info ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = rounded(panel); pad(this, 12)
            }
            val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager)) }
            row.addView(icon, LinearLayout.LayoutParams(44,44))
            val name = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12,0,0,0); layoutParams = LinearLayout.LayoutParams(0,-2,1f) }
            name.addView(label(info.loadLabel(packageManager).toString(), 14f, Color.WHITE, true))
            name.addView(label(info.activityInfo.packageName, 9f, Color.GRAY))
            row.addView(name)
            val open = Button(this).apply {
                text = "OPEN"; textSize = 10f; isAllCaps = false
                setTextColor(Color.WHITE); background = rounded(red, 12f)
                setOnClickListener {
                    packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)?.let { startActivity(it) }
                }
            }
            row.addView(open, LinearLayout.LayoutParams(-2, 42))
            val lp = LinearLayout.LayoutParams(-1,-2); lp.bottomMargin = 9
            content.addView(row, lp)
        }
    }

    private fun showTools() {
        content.removeAllViews()
        title("Gaming tools", "Pusat fitur RGAME GANIE P.")
        content.addView(card("Performance monitor", "FPS / RAM / CPU / GPU / suhu — belum diaktifkan."))
        content.addView(card("Screenshot & screen recording", "Akan memakai izin Android saat fitur dikembangkan."))
        content.addView(card("Custom crosshair", "Overlay visual; tidak mengubah bidikan atau gameplay."))
        content.addView(card("Game timer & quick apps", "Fitur lanjutan dalam tahap pengembangan."))
    }

    private fun showSettings() {
        content.removeAllViews()
        title("Settings", "Pengaturan lokal aplikasi.")
        val prefs = getSharedPreferences("rgame_settings", MODE_PRIVATE)
        val box = card("Tampilan", "Tema Red Cyber")
        content.addView(box)
        val seek = SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("opacity", 85)
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, value: Int, user: Boolean) {
                    if (user) prefs.edit().putInt("opacity", value).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        content.addView(label("Preferensi transparansi (tersimpan lokal)", 12f, Color.LTGRAY))
        content.addView(seek)
        content.addView(card("Versi aplikasi", "RGAME GANIE P v0.1.0 • Prototype"))
        content.addView(card("Privasi", "Tidak memerlukan akun. Pengaturan disimpan di perangkat."))
    }
}
